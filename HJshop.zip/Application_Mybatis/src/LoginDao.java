
public interface LoginDao {
	public boolean isVaild(String id, String pw);

	public boolean isAdmin(String id);
}



public interface MyshopDao {
	public void get(PageUtil<Myshop> page, String id);
	public void getAll(PageUtil<Myshop> page);

}

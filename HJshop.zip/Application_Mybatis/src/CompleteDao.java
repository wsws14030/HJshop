
public interface CompleteDao {
	public int addOrder(String id, String name, String address, String email, String phone);

	public void addProduct(Integer ono, Integer no);
}
